import venda
import csv


class Vendas:

    def __init__(self, path):
        self.path = path
        self.vendas = []
        self.read_csv()
    def read_csv(self):

        try:

            with open(self.path, 'r') as file:

                read_file = csv.reader(file)

                next(read_file)

                for linha in read_file:
                    nova_venda = venda.Venda(linha[0], linha[1], linha[2], linha[3], linha[4], linha[5], linha[6],
                                             linha[7])

                    self.vendas.append(nova_venda)

        except Exception as e:
            print(e)

    def write_csv(self, nome):
        with open(f'{nome}.csv', 'w', newline='\n') as arquivo:
            writer = csv.writer(arquivo)

            for venda in self.vendas:
                writer.writerow([
                    venda.sku,
                    venda.produto,
                    venda.quantidade_vendida,
                    venda.primeiro_nome,
                    venda.sobre_nome,
                    venda.data,
                    venda.loja,
                    venda.preco_unitario,
                    venda.get_total()
                ])



    def get_soma_vendas(self):
        total = 0

        for venda in self.vendas:
            total += venda.get_total()

        return total

    def get_maior_venda(self):
        lista = []

        for venda in self.vendas:
            lista.append(venda.get_total())

        return max(lista)

    def get_menor_venda(self):
        lista = []

        for venda in self.vendas:
            lista.append(venda.get_total())

        return min(lista)
