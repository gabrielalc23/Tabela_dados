class Venda:

    def __init__(self, sku, produto, quantidade_vendida, primeiro_nome, sobre_nome, data, loja, preco_unitario):
        self.sku = sku
        self.produto = produto
        self.quantidade_vendida = int(quantidade_vendida)
        self.primeiro_nome = primeiro_nome
        self.sobre_nome = sobre_nome
        self.data = data
        self.loja = loja
        self.preco_unitario = float(preco_unitario)

    def get_total(self):
        return self.preco_unitario * self.quantidade_vendida
