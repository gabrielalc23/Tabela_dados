from flask import Flask, render_template
import vendas

app = Flask(__name__)

@app.route('/')
def index():
    listagem_vendas = vendas.Vendas('vendas.csv')
    return render_template('index.html', venda=listagem_vendas.vendas)

if __name__ == "__main__":
    app.run()
